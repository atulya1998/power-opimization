"""
replay_buffer.py — Experience replay memory
ddpg_agent.py    — DDPG agent for HetNet power optimisation
"""

import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from collections import deque
import random

from ..networks.actor_critic import Actor, Critic


# ======================================================================
# Replay Buffer
# ======================================================================

class ReplayBuffer:
    """
    Fixed-size circular experience replay buffer.
    Stores (s, a, r, s', done) transitions.
    """

    def __init__(self, capacity=100_000):
        self.buffer = deque(maxlen=capacity)

    def push(self, state, action, reward, next_state, done):
        self.buffer.append((
            np.array(state,      dtype=np.float32),
            np.array(action,     dtype=np.float32),
            float(reward),
            np.array(next_state, dtype=np.float32),
            float(done)
        ))

    def sample(self, batch_size):
        batch = random.sample(self.buffer, batch_size)
        s, a, r, ns, d = zip(*batch)
        return (
            torch.FloatTensor(np.stack(s)),
            torch.FloatTensor(np.stack(a)),
            torch.FloatTensor(r).unsqueeze(1),
            torch.FloatTensor(np.stack(ns)),
            torch.FloatTensor(d).unsqueeze(1),
        )

    def __len__(self):
        return len(self.buffer)


# ======================================================================
# Ornstein-Uhlenbeck Noise (correlated exploration)
# ======================================================================

class OUNoise:
    def __init__(self, size, mu=0.0, theta=0.15, sigma=0.2):
        self.size  = size
        self.mu    = mu * np.ones(size)
        self.theta = theta
        self.sigma = sigma
        self.reset()

    def reset(self):
        self.state = self.mu.copy()

    def sample(self):
        dx = (self.theta * (self.mu - self.state)
              + self.sigma * np.random.randn(self.size))
        self.state += dx
        return self.state


# ======================================================================
# DDPG Agent
# ======================================================================

class DDPGAgent:
    """
    Deep Deterministic Policy Gradient agent.
    Solves the HetNet power optimisation MDP.

    Key design choices:
    - Twin critics (TD3-style) to reduce overestimation
    - Soft target updates (Polyak averaging)
    - Ornstein-Uhlenbeck noise for temporally correlated exploration
    - Gradient clipping for stable training
    """

    def __init__(self, state_dim, action_dim,
                 lr_actor=1e-4, lr_critic=1e-3,
                 gamma=0.99, tau=0.005,
                 buffer_size=100_000,
                 hidden_dim=256,
                 device=None):

        self.state_dim  = state_dim
        self.action_dim = action_dim
        self.gamma      = gamma
        self.tau        = tau
        self.device     = device or (
            torch.device('cuda') if torch.cuda.is_available()
            else torch.device('cpu')
        )

        # ── Networks ──────────────────────────────────────────────────
        self.actor          = Actor(state_dim, action_dim, hidden_dim).to(self.device)
        self.actor_target   = Actor(state_dim, action_dim, hidden_dim).to(self.device)
        self.critic         = Critic(state_dim, action_dim, hidden_dim).to(self.device)
        self.critic_target  = Critic(state_dim, action_dim, hidden_dim).to(self.device)

        # Hard copy weights to targets
        self.actor_target.load_state_dict(self.actor.state_dict())
        self.critic_target.load_state_dict(self.critic.state_dict())

        # ── Optimisers ────────────────────────────────────────────────
        self.actor_opt  = optim.Adam(self.actor.parameters(),  lr=lr_actor)
        self.critic_opt = optim.Adam(self.critic.parameters(), lr=lr_critic)

        # ── Memory & Noise ────────────────────────────────────────────
        self.replay_buffer = ReplayBuffer(buffer_size)
        self.noise         = OUNoise(action_dim)
        self.noise_scale   = 0.1

    # ------------------------------------------------------------------

    def select_action(self, state, explore=True):
        """
        Choose action given current state.
        explore=True adds OU noise for exploration.
        """
        state_t = torch.FloatTensor(state).unsqueeze(0).to(self.device)
        self.actor.eval()
        with torch.no_grad():
            action = self.actor(state_t).cpu().numpy().squeeze(0)
        self.actor.train()

        if explore:
            noise  = self.noise.sample() * self.noise_scale
            action = np.clip(action + noise, 0.0, 1.0)

        return action

    # ------------------------------------------------------------------

    def train_step(self, batch_size=64):
        """
        One gradient update step.
        Returns (actor_loss, critic_loss) or (None, None) if buffer too small.
        """
        if len(self.replay_buffer) < batch_size:
            return None, None

        states, actions, rewards, next_states, dones = \
            self.replay_buffer.sample(batch_size)

        states      = states.to(self.device)
        actions     = actions.to(self.device)
        rewards     = rewards.to(self.device)
        next_states = next_states.to(self.device)
        dones       = dones.to(self.device)

        # ── Critic update ──────────────────────────────────────────────
        with torch.no_grad():
            next_actions = self.actor_target(next_states)
            q1_t, q2_t  = self.critic_target(next_states, next_actions)
            q_target     = rewards + self.gamma * (1 - dones) * torch.min(q1_t, q2_t)

        q1, q2       = self.critic(states, actions)
        critic_loss  = (nn.MSELoss()(q1, q_target)
                        + nn.MSELoss()(q2, q_target))

        self.critic_opt.zero_grad()
        critic_loss.backward()
        nn.utils.clip_grad_norm_(self.critic.parameters(), 1.0)
        self.critic_opt.step()

        # ── Actor update ───────────────────────────────────────────────
        actor_loss = -self.critic.Q1(states, self.actor(states)).mean()

        self.actor_opt.zero_grad()
        actor_loss.backward()
        nn.utils.clip_grad_norm_(self.actor.parameters(), 1.0)
        self.actor_opt.step()

        # ── Soft target update (Polyak averaging) ─────────────────────
        self._soft_update(self.actor,  self.actor_target)
        self._soft_update(self.critic, self.critic_target)

        return actor_loss.item(), critic_loss.item()

    # ------------------------------------------------------------------

    def _soft_update(self, source, target):
        """θ_target ← τ·θ_source + (1-τ)·θ_target"""
        for s, t in zip(source.parameters(), target.parameters()):
            t.data.copy_(self.tau * s.data + (1 - self.tau) * t.data)

    def decay_noise(self, factor=0.995, min_scale=0.01):
        self.noise_scale = max(min_scale, self.noise_scale * factor)

    # ------------------------------------------------------------------

    def save(self, path):
        torch.save({
            'actor' : self.actor.state_dict(),
            'critic': self.critic.state_dict(),
        }, path)
        print(f"[DDPG] Model saved → {path}")

    def load(self, path):
        ckpt = torch.load(path, map_location=self.device)
        self.actor.load_state_dict(ckpt['actor'])
        self.critic.load_state_dict(ckpt['critic'])
        self.actor_target.load_state_dict(ckpt['actor'])
        self.critic_target.load_state_dict(ckpt['critic'])
        print(f"[DDPG] Model loaded ← {path}")
