"""
hetnet_env.py
-------------
Main 5G HetNet Gym-compatible environment.
Implements the system model from Section 3 of the paper.
"""

import numpy as np
import gym
from gym import spaces

from .channel_model import ChannelModel
from .power_model import PowerModel
from .constraint_handler import ConstraintHandler


class HetNetEnv(gym.Env):
    """
    5G Heterogeneous Network Environment for DRL.

    Network topology (Section 3 of paper):
    - 1 MBS at centre (500m coverage)
    - N s-BSs grouped into clusters
    - mmWave BH: 73 GHz (E-band) for a-sBS↔MBS
                 60 GHz (V-band) for s-BS↔s-BS
    - UEs: 2/3 random + 1/3 uniform distribution
    - GBR: 300 Mbps (10%), 200 Mbps (20%), 100 Mbps (70%)
    """

    metadata = {'render.modes': ['human']}

    def __init__(self, cfg, reward_cfg):
        super().__init__()

        self.cfg        = cfg
        self.n_ue       = cfg['n_ue']
        self.n_sbs      = cfg['n_sbs']
        self.n_mbs      = cfg['n_mbs']
        self.n_bs       = self.n_sbs + self.n_mbs
        self.Gamma_max  = cfg['Gamma_max']
        self.coverage   = cfg['mbs_coverage']

        # Sub-modules
        self.channel  = ChannelModel(cfg)
        self.power    = PowerModel(cfg)
        self.constraints = ConstraintHandler(cfg, reward_cfg)
        self.P_ref    = reward_cfg['P_ref']

        # Spaces
        self.state_dim  = self._state_dim()
        self.action_dim = self._action_dim()

        self.observation_space = spaces.Box(
            low=-np.inf, high=np.inf,
            shape=(self.state_dim,), dtype=np.float32
        )
        self.action_space = spaces.Box(
            low=0.0, high=1.0,
            shape=(self.action_dim,), dtype=np.float32
        )

        # Internal state
        self.ue_positions  = None
        self.bs_positions  = None
        self.ue_demands    = None
        self.sinr_matrix   = None
        self.prb_required  = None
        self.bs_types      = None
        self.node_types    = None
        self.step_count    = 0

    # ------------------------------------------------------------------
    # Dimensions
    # ------------------------------------------------------------------

    def _state_dim(self):
        return (self.n_bs           # BS PRB utilisation
                + self.n_sbs        # BH link loads
                + self.n_ue         # UE demands (normalised)
                + self.n_sbs        # s-BS active/sleep states
                + self.n_sbs        # BH link active/sleep states
                + self.n_ue * self.n_bs)  # SINR matrix (flattened)

    def _action_dim(self):
        return (self.n_ue * self.n_bs   # UE association X^AN
                + self.n_sbs * self.n_bs  # BH routing X^BH (simplified)
                + self.n_sbs            # s-BS sleep decisions S^AN
                + self.n_sbs)           # BH link sleep decisions S^BH

    # ------------------------------------------------------------------
    # Reset
    # ------------------------------------------------------------------

    def reset(self):
        """Reset network topology and return initial state."""
        np.random.seed(None)  # fresh random each episode

        # BS positions: MBS at centre, s-BSs random
        self.bs_positions = np.zeros((self.n_bs, 2))
        self.bs_positions[0] = [self.coverage / 2, self.coverage / 2]
        self.bs_positions[1:] = np.random.uniform(
            50, self.coverage - 50, (self.n_sbs, 2)
        )

        # UE positions: 2/3 random, 1/3 uniform grid
        n_rand = int(self.n_ue * 2 / 3)
        n_unif = self.n_ue - n_rand
        rand_pos  = np.random.uniform(0, self.coverage, (n_rand, 2))
        grid_side = int(np.ceil(np.sqrt(n_unif)))
        xs = np.linspace(50, self.coverage - 50, grid_side)
        ys = np.linspace(50, self.coverage - 50, grid_side)
        grid = np.array([[x, y] for x in xs for y in ys])[:n_unif]
        self.ue_positions = np.vstack([rand_pos, grid])

        # UE data rate demands (GBR distribution from paper)
        self.ue_demands = np.random.choice(
            [300e6, 200e6, 100e6],
            size=self.n_ue,
            p=[0.10, 0.20, 0.70]
        )

        # BS types and TX powers
        self.bs_types = ['mbs'] + ['sbs'] * self.n_sbs
        tx_powers_w   = np.array(
            [self.cfg['T_AN_max_mbs']] +
            [self.cfg['T_AN_max_sbs']] * self.n_sbs
        )

        # SINR matrix (n_ue × n_bs)
        self.sinr_matrix = self.channel.compute_sinr_matrix(
            self.ue_positions, self.bs_positions,
            tx_powers_w, self.bs_types
        )

        # PRB required matrix (n_ue × n_bs)
        self.prb_required = np.zeros((self.n_ue, self.n_bs))
        for u in range(self.n_ue):
            for i in range(self.n_bs):
                self.prb_required[u, i] = self.channel.compute_prb(
                    self.ue_demands[u], self.sinr_matrix[u, i]
                )
        self.prb_required = np.clip(self.prb_required, 0, self.Gamma_max * 2)

        # Node types for flow conservation (C7)
        # MBS = sink (-1), s-BSs = intermediate (0) initially
        self.node_types = np.zeros(self.n_bs)
        self.node_types[0] = -1   # MBS is the sink

        self.step_count = 0
        return self._get_state()

    # ------------------------------------------------------------------
    # Step
    # ------------------------------------------------------------------

    def step(self, action):
        """
        Execute action and return (next_state, reward, done, info).

        Action vector layout:
          [0 : n_ue*n_bs]                  → X^AN  UE association
          [n_ue*n_bs : n_ue*n_bs+n_sbs*n_bs] → X^BH  BH routing
          [... : ...+n_sbs]                → S^AN  s-BS sleep
          [... : ...+n_sbs]                → S^BH  BH link sleep
        """
        action = np.clip(action, 0.0, 1.0)
        self.step_count += 1

        # ── Parse action ──────────────────────────────────────────────
        idx = 0
        ue_assoc_flat = action[idx: idx + self.n_ue * self.n_bs]
        idx += self.n_ue * self.n_bs

        bh_flat = action[idx: idx + self.n_sbs * self.n_bs]
        idx += self.n_sbs * self.n_bs

        sleep_bs  = action[idx: idx + self.n_sbs]
        idx += self.n_sbs
        sleep_bh  = action[idx: idx + self.n_sbs]

        # ── Binarise decisions ────────────────────────────────────────
        # UE association: softmax over BS dimension per UE (satisfies C8)
        ue_assoc_raw = ue_assoc_flat.reshape(self.n_ue, self.n_bs)
        ue_association = np.zeros_like(ue_assoc_raw)
        for u in range(self.n_ue):
            best_bs = np.argmax(ue_assoc_raw[u])
            ue_association[u, best_bs] = 1.0

        # BH routing matrix
        X_BH_raw  = bh_flat.reshape(self.n_sbs, self.n_bs)
        X_BH_bin  = (X_BH_raw >= 0.5).astype(float)

        # Full BH matrix including MBS row/col
        X_BH_full = np.zeros((self.n_bs, self.n_bs))
        X_BH_full[1:, :] = X_BH_bin

        # C3: enforce no bidirectional
        raw_probs_full = np.zeros((self.n_bs, self.n_bs))
        raw_probs_full[1:, :] = X_BH_raw
        X_BH_full = self.constraints.enforce_c3(X_BH_full, raw_probs_full)

        # BS and BH sleep states (0=sleep, 1=active)
        bs_states = np.ones(self.n_bs)       # MBS always active
        bs_states[1:] = (sleep_bs < 0.5).astype(float)

        bh_states = (sleep_bh < 0.5).astype(float)

        # Update node types based on which s-BSs have UEs
        self.node_types = np.zeros(self.n_bs)
        self.node_types[0] = -1
        for i in range(1, self.n_bs):
            if np.sum(ue_association[:, i]) > 0:
                self.node_types[i] = 1   # source

        # ── Compute PRBs used per BS ───────────────────────────────────
        prb_used_per_bs = np.array([
            np.sum(ue_association[:, i] * self.prb_required[:, i])
            for i in range(self.n_bs)
        ])

        # ── BH dynamic power ───────────────────────────────────────────
        p_BH_d_per_link = np.zeros(self.n_sbs)
        for l in range(self.n_sbs):
            i = l + 1  # s-BS index
            agg_traffic = np.sum(ue_association[:, i] * self.ue_demands)
            dist = np.linalg.norm(
                self.bs_positions[i] - self.bs_positions[0]
            )
            band = 'eband' if l < self.cfg.get('n_asbs', 2) else 'vband'
            p_raw = self.channel.dynamic_bh_power(agg_traffic, dist, band)
            T_max = self.channel.max_bh_tx_power(band)
            # C6: hard clipping
            p_BH_d_per_link[l] = self.constraints.enforce_c6(p_raw, T_max)

        # ── Power computation ──────────────────────────────────────────
        P_Net, P_AN, P_BH = self.power.compute_P_Net(
            bs_states, prb_used_per_bs,
            bh_states, p_BH_d_per_link
        )

        # ── Constraint penalties ───────────────────────────────────────
        pen = self.constraints.compute_all_penalties(
            bs_states       = bs_states,
            X_BH            = X_BH_full,
            node_types      = self.node_types,
            ue_association  = ue_association,
            prb_required    = self.prb_required,
            ue_demands      = self.ue_demands,
            raw_probs       = raw_probs_full
        )

        # ── Reward ────────────────────────────────────────────────────
        reward = (- P_Net / self.P_ref
                  + pen['qos_reward']
                  - pen['penalty_c4']
                  - pen['penalty_c5']
                  - pen['penalty_c7'])

        # ── Energy efficiency ──────────────────────────────────────────
        total_prb = float(np.sum(
            ue_association * self.prb_required
        ))
        EE = self.power.compute_EE(total_prb, P_Net)

        n_active_sbs  = int(np.sum(bs_states[1:]))
        n_active_bh   = int(np.sum(bh_states))
        qos_count     = int(pen['qos_reward'] / self.constraints.lambda1
                            * self.n_ue)

        info = {
            'P_Net'       : P_Net,
            'P_AN'        : P_AN,
            'P_BH'        : P_BH,
            'EE'          : EE,
            'n_active_sbs': n_active_sbs,
            'n_active_bh' : n_active_bh,
            'qos_satisfied': qos_count,
            'penalty_c4'  : pen['penalty_c4'],
            'penalty_c5'  : pen['penalty_c5'],
            'penalty_c7'  : pen['penalty_c7'],
        }

        done = False
        return self._get_state(), reward, done, info

    # ------------------------------------------------------------------
    # State construction
    # ------------------------------------------------------------------

    def _get_state(self):
        """Build normalised state vector."""
        # BS PRB utilisation (normalised by Gamma_max)
        bs_loads = np.zeros(self.n_bs)

        # BH link loads (placeholder — updated in step)
        bh_loads = np.zeros(self.n_sbs)

        # UE demands normalised
        ue_demands_norm = self.ue_demands / 300e6

        # BS active states (s-BSs only, MBS always 1)
        bs_states_norm = np.ones(self.n_sbs)

        # BH link states
        bh_states_norm = np.ones(self.n_sbs)

        # SINR matrix normalised
        sinr_min = self.sinr_matrix.min()
        sinr_max = self.sinr_matrix.max()
        sinr_range = sinr_max - sinr_min + 1e-8
        sinr_norm = (self.sinr_matrix - sinr_min) / sinr_range

        state = np.concatenate([
            bs_loads,
            bh_loads,
            ue_demands_norm,
            bs_states_norm,
            bh_states_norm,
            sinr_norm.flatten()
        ]).astype(np.float32)

        return state

    # ------------------------------------------------------------------
    # Render
    # ------------------------------------------------------------------

    def render(self, mode='human'):
        print(f"Step {self.step_count} | "
              f"UEs: {self.n_ue} | s-BSs: {self.n_sbs}")
