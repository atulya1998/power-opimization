"""
constraint_handler.py
---------------------
Handles all constraints C1-C8 from the optimization problem.

Strategy:
  Hard enforcement : C3 (no bidirectional), C6 (BH power clip)
  Learnable penalty: C4 (BS active), C5 (PRB capacity), C7 (flow)
  Architecture     : C1, C2 (binary via Sigmoid + threshold)
  Reward bonus     : C8 (QoS guarantee)
"""

import numpy as np


class ConstraintHandler:
    """
    Computes penalty terms and enforces hard constraints
    corresponding to C1-C8 in Equation (14) of the paper.
    """

    def __init__(self, cfg, reward_cfg):
        self.Gamma_max = cfg['Gamma_max']
        self.lambda1   = reward_cfg['lambda1']  # QoS weight
        self.lambda2   = reward_cfg['lambda2']  # C5 PRB penalty
        self.lambda3   = reward_cfg['lambda3']  # C7 flow penalty
        self.lambda4   = reward_cfg['lambda4']  # C4 BS active penalty

    # ------------------------------------------------------------------
    # C1 & C2 — Binary Variables
    # Handled in neural network architecture via Sigmoid + threshold.
    # See binary_layer.py for Straight-Through Estimator.
    # ------------------------------------------------------------------

    # ------------------------------------------------------------------
    # C3 — No Bidirectional Transmission  (Hard Enforcement)
    # X^BH_ij + X^BH_ji <= 1
    # ------------------------------------------------------------------

    def enforce_c3(self, X_BH, raw_probs):
        """
        Post-processing to ensure no bidirectional BH traffic.
        Keeps the direction with the higher raw probability.

        X_BH      : (n_bs, n_bs) binary routing matrix
        raw_probs : (n_bs, n_bs) raw sigmoid probabilities
        Returns corrected X_BH.
        """
        X = X_BH.copy().astype(float)
        n = X.shape[0]
        for i in range(n):
            for j in range(i + 1, n):
                if X[i, j] == 1 and X[j, i] == 1:
                    # Keep direction with higher confidence
                    if raw_probs[i, j] >= raw_probs[j, i]:
                        X[j, i] = 0.0
                    else:
                        X[i, j] = 0.0
        return X

    # ------------------------------------------------------------------
    # C4 — BS Must Be Active if Routing Traffic  (Penalty)
    # S^AN_i >= X^BH_ij + X^BH_ji
    # ------------------------------------------------------------------

    def penalty_c4(self, bs_states, X_BH):
        """
        Penalty when a sleeping BS is used for BH routing.

        bs_states : (n_bs,) active/sleep states
        X_BH      : (n_bs, n_bs) BH routing matrix
        """
        violation = 0.0
        n = len(bs_states)
        for i in range(n):
            if bs_states[i] == 0:  # BS is sleeping
                routed = np.sum(X_BH[i, :]) + np.sum(X_BH[:, i])
                violation += max(0.0, float(routed))
        return self.lambda4 * violation

    # ------------------------------------------------------------------
    # C5 — PRB Capacity Constraint  (Quadratic Penalty)
    # sum_u X^AN_iu * Gamma_iu <= Gamma_max
    # ------------------------------------------------------------------

    def penalty_c5(self, ue_association, prb_required):
        """
        Quadratic penalty for PRB capacity violations.

        ue_association : (n_ue, n_bs) binary association matrix
        prb_required   : (n_ue, n_bs) PRBs needed per UE-BS pair
        """
        violation = 0.0
        n_bs = ue_association.shape[1]
        for i in range(n_bs):
            prb_used = np.sum(ue_association[:, i] * prb_required[:, i])
            excess   = max(0.0, prb_used - self.Gamma_max)
            violation += excess ** 2   # quadratic penalty
        return self.lambda2 * violation

    # ------------------------------------------------------------------
    # C6 — BH Power Limit  (Hard Clipping)
    # p^BH_d_ij <= T^BH_max_ij
    # ------------------------------------------------------------------

    def enforce_c6(self, p_BH_d, T_BH_max):
        """
        Hard clipping to enforce BH transmission power limit.
        Always produces feasible values — no penalty needed.

        p_BH_d   : (n_links,) or scalar dynamic BH power
        T_BH_max : maximum allowed BH power (scalar or array)
        """
        return np.clip(p_BH_d, a_min=0.0, a_max=T_BH_max)

    # ------------------------------------------------------------------
    # C7 — Flow Conservation  (Penalty)
    # sum_i X^BH_ij - sum_i X^BH_ji = {+1 source, -1 sink, 0 intermediate}
    # ------------------------------------------------------------------

    def penalty_c7(self, X_BH, node_types):
        """
        Flow conservation penalty at each node.

        X_BH       : (n_bs, n_bs) BH routing matrix
        node_types : (n_bs,) array with values +1 / -1 / 0
                     +1 = source (s-BS with UE traffic)
                     -1 = sink   (MBS)
                      0 = intermediate node
        """
        violation = 0.0
        n = len(node_types)
        for i in range(n):
            outflow = np.sum(X_BH[i, :])
            inflow  = np.sum(X_BH[:, i])
            b_i     = node_types[i]
            violation += abs(outflow - inflow - b_i)
        return self.lambda3 * violation

    # ------------------------------------------------------------------
    # C8 — QoS Guarantee  (Positive Reward)
    # Each UE must be served with its required data rate
    # ------------------------------------------------------------------

    def qos_reward(self, ue_association, prb_required, ue_demands):
        """
        Reward for satisfying UE QoS demands.
        Returns fraction of UEs with satisfied QoS.

        ue_association : (n_ue, n_bs) binary matrix
        prb_required   : (n_ue, n_bs) PRBs required
        ue_demands     : (n_ue,) data rate demands
        """
        n_ue = ue_association.shape[0]
        satisfied = 0
        for u in range(n_ue):
            # UE is served if associated to exactly one BS
            if np.sum(ue_association[u, :]) == 1:
                bs_idx = np.argmax(ue_association[u, :])
                if prb_required[u, bs_idx] <= self.Gamma_max:
                    satisfied += 1
        return self.lambda1 * (satisfied / n_ue)

    # ------------------------------------------------------------------
    # Composite Penalty
    # ------------------------------------------------------------------

    def compute_all_penalties(self, bs_states, X_BH, node_types,
                               ue_association, prb_required,
                               ue_demands, raw_probs=None):
        """
        Compute total constraint penalty for reward function.
        Returns dict with individual and total penalties.
        """
        # Hard constraints (post-process, no penalty value)
        if raw_probs is not None:
            X_BH = self.enforce_c3(X_BH, raw_probs)

        # Soft constraint penalties
        pen_c4 = self.penalty_c4(bs_states, X_BH)
        pen_c5 = self.penalty_c5(ue_association, prb_required)
        pen_c7 = self.penalty_c7(X_BH, node_types)
        qos_r  = self.qos_reward(ue_association, prb_required, ue_demands)

        total_penalty = pen_c4 + pen_c5 + pen_c7

        return {
            'penalty_c4'   : pen_c4,
            'penalty_c5'   : pen_c5,
            'penalty_c7'   : pen_c7,
            'qos_reward'   : qos_r,
            'total_penalty': total_penalty,
            'X_BH_fixed'   : X_BH          # C3-corrected routing matrix
        }
