"""
power_model.py
--------------
AN and BH power consumption models.
Implements Equations 3-10 from the paper.
"""

import numpy as np


class PowerModel:
    """
    Linear approximation power consumption model
    for both Access Network (AN) and Backhaul (BH).
    """

    def __init__(self, cfg):
        # AN parameters
        self.T_AN_X_mbs   = cfg['T_AN_X_mbs']    # transceiver chains MBS
        self.T_AN_X_sbs   = cfg['T_AN_X_sbs']    # transceiver chains s-BS
        self.T_AN_max_mbs = cfg['T_AN_max_mbs']  # max TX power MBS (W)
        self.T_AN_max_sbs = cfg['T_AN_max_sbs']  # max TX power s-BS (W)
        self.p_AN_o_mbs   = cfg['p_AN_o_mbs']    # static power MBS (W)
        self.p_AN_o_sbs   = cfg['p_AN_o_sbs']    # static power s-BS (W)
        self.delta_AN_mbs = cfg['delta_AN_mbs']  # slope MBS
        self.delta_AN_sbs = cfg['delta_AN_sbs']  # slope s-BS
        self.Gamma_max    = cfg['Gamma_max']      # max PRBs

        # BH parameters
        self.T_BH_X   = cfg['T_BH_X']    # transceiver chains BH
        self.p_BH_o   = cfg['p_BH_o']    # static BH power (W)
        self.delta_BH = cfg['delta_BH']  # slope BH

    # ------------------------------------------------------------------
    # Access Network Power  (Eq. 5-6)
    # ------------------------------------------------------------------

    def compute_p_AN_dynamic(self, bs_idx, prb_used, is_mbs=False):
        """
        Dynamic power consumption of i-th BS (Eq. 6).
        p^AN_d_i = (T^AN_max_i / Gamma_max_i) * sum(X^AN * Gamma)
        """
        T_max = self.T_AN_max_mbs if is_mbs else self.T_AN_max_sbs
        return (T_max / self.Gamma_max) * prb_used

    def compute_P_AN(self, bs_states, prb_used_per_bs, n_mbs=1):
        """
        Total AN power consumption (Eq. 5).
        P^AN = sum_i T^AN_X_i * (S^AN_i * p^AN_o_i + Δ^AN_p_i * p^AN_d_i)

        bs_states      : (n_bs,) array, 1=active 0=sleep
        prb_used_per_bs: (n_bs,) total PRBs used at each BS
        n_mbs          : number of MBSs (index 0..n_mbs-1)
        """
        P_AN = 0.0
        for i, state in enumerate(bs_states):
            is_mbs = (i < n_mbs)
            T_X    = self.T_AN_X_mbs   if is_mbs else self.T_AN_X_sbs
            p_o    = self.p_AN_o_mbs   if is_mbs else self.p_AN_o_sbs
            delta  = self.delta_AN_mbs if is_mbs else self.delta_AN_sbs

            p_d = self.compute_p_AN_dynamic(i, prb_used_per_bs[i], is_mbs)
            P_AN += T_X * (state * p_o + delta * p_d)
        return P_AN

    # ------------------------------------------------------------------
    # Backhaul Power  (Eq. 7-10)
    # ------------------------------------------------------------------

    def compute_P_BH(self, bh_states, p_BH_d_per_link):
        """
        Total BH power consumption (Eq. 7).
        P^BH = sum_l T^BH_X_l * (S^BH_l * p^BH_o_l + Δ^BH_p_l * p^BH_d_l)

        bh_states        : (n_links,) array, 1=active 0=sleep
        p_BH_d_per_link  : (n_links,) dynamic power per BH link (dBm)
        """
        P_BH = 0.0
        for l, state in enumerate(bh_states):
            # Convert dBm to Watts for dynamic power
            p_d_w = 10 ** ((p_BH_d_per_link[l] - 30) / 10)
            P_BH += self.T_BH_X * (state * self.p_BH_o
                                    + self.delta_BH * p_d_w)
        return P_BH

    # ------------------------------------------------------------------
    # Total Network Power  (Eq. 3)
    # ------------------------------------------------------------------

    def compute_P_Net(self, bs_states, prb_used_per_bs,
                      bh_states, p_BH_d_per_link, n_mbs=1):
        """
        Total network power consumption (Eq. 3).
        P^Net = P^AN + P^BH
        """
        P_AN = self.compute_P_AN(bs_states, prb_used_per_bs, n_mbs)
        P_BH = self.compute_P_BH(bh_states, p_BH_d_per_link)
        return P_AN + P_BH, P_AN, P_BH

    # ------------------------------------------------------------------
    # Network Energy Efficiency  (Eq. 4)
    # ------------------------------------------------------------------

    def compute_EE(self, total_prb_served, P_Net):
        """
        Network energy efficiency (Eq. 4).
        Net_ee = sum(X^AN * Gamma) / P^Net   [bits/Joule]
        """
        if P_Net <= 0:
            return 0.0
        return total_prb_served / P_Net
