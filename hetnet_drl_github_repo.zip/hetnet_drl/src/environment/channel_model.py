"""
channel_model.py
----------------
SINR and path loss models for 5G HetNet.
Based on 3GPP TR 36.872 parameters from the paper.
"""

import numpy as np


class ChannelModel:
    """
    Computes SINR and path loss for UE-BS and BS-BS links.

    Parameters (from Table 2 / Section 5.1 of paper):
    - UE to MBS path loss: 128.1 + 37.6*log10(d_km)
    - UE to s-BS path loss: 140.7 + 36.7*log10(d_km)
    - Carrier frequency AN: 2 GHz, BW: 20 MHz
    - BH links: 60 GHz (V-band) and 73 GHz (E-band)
    """

    def __init__(self, cfg):
        self.cfg = cfg
        self.eta_an  = cfg['bandwidth_an']   # 20 MHz
        self.eta_bh  = cfg['bandwidth_bh']   # 200 MHz
        self.N_f     = cfg['N_f']            # 30 dB noise figure
        self.T_n     = cfg['T_n']            # -174 dBm/Hz thermal noise
        self.L_rx    = cfg['L_rx']           # 5 dB receiver loss
        self.L_M     = cfg['L_M']            # 15 dB link margin
        self.G_rx_vband = cfg['G_rx_vband']  # 36 dBi V-band gain
        self.G_rx_eband = cfg['G_rx_eband']  # 43 dBi E-band gain

    # ------------------------------------------------------------------
    # Access Network (UE ↔ BS)
    # ------------------------------------------------------------------

    def path_loss_an(self, distance_m, bs_type='sbs'):
        """
        Path loss model for access network links.
        distance_m: distance in metres
        bs_type   : 'mbs' or 'sbs'
        Returns path loss in dB.
        """
        d_km = max(distance_m, 1.0) / 1000.0
        if bs_type == 'mbs':
            return 128.1 + 37.6 * np.log10(d_km)
        else:
            return 140.7 + 36.7 * np.log10(d_km)

    def sinr_an(self, tx_power_dbm, path_loss_db,
                interference_dbm=-np.inf):
        """
        Compute SINR for access network link (dB).
        tx_power_dbm      : transmit power in dBm
        path_loss_db      : path loss in dB
        interference_dbm  : interference power in dBm
        """
        rx_power_dbm = tx_power_dbm - path_loss_db
        noise_dbm = self.T_n + 10 * np.log10(self.eta_an) + self.N_f

        rx_linear = 10 ** (rx_power_dbm / 10)
        noise_linear = 10 ** (noise_dbm / 10)

        if interference_dbm > -np.inf:
            intf_linear = 10 ** (interference_dbm / 10)
        else:
            intf_linear = 0.0

        sinr = rx_linear / (noise_linear + intf_linear)
        return 10 * np.log10(max(sinr, 1e-10))

    def compute_sinr_matrix(self, ue_positions, bs_positions,
                             bs_tx_power_w, bs_types):
        """
        Compute full UE×BS SINR matrix.

        ue_positions  : (n_ue, 2) array of UE coords (metres)
        bs_positions  : (n_bs, 2) array of BS coords (metres)
        bs_tx_power_w : (n_bs,) transmit power in Watts
        bs_types      : list of 'mbs'/'sbs' for each BS
        Returns (n_ue, n_bs) SINR matrix in dB.
        """
        n_ue = ue_positions.shape[0]
        n_bs = bs_positions.shape[0]
        sinr_matrix = np.zeros((n_ue, n_bs))

        for u in range(n_ue):
            for i in range(n_bs):
                dist = np.linalg.norm(
                    ue_positions[u] - bs_positions[i]
                )
                pl = self.path_loss_an(dist, bs_types[i])
                tx_dbm = 10 * np.log10(bs_tx_power_w[i] * 1000)
                sinr_matrix[u, i] = self.sinr_an(tx_dbm, pl)

        return sinr_matrix

    # ------------------------------------------------------------------
    # Backhaul Network (BS ↔ BS)
    # ------------------------------------------------------------------

    def path_loss_bh(self, distance_m, band='vband'):
        """
        mmWave backhaul path loss (free-space + rain + gas).
        band: 'vband' (60 GHz) or 'eband' (73 GHz)
        Returns path loss in dB.
        """
        d_m = max(distance_m, 1.0)
        if band == 'vband':
            freq_ghz = 60.0
            # Free-space + atmospheric attenuation
            fs_pl = 20 * np.log10(d_m) + 20 * np.log10(freq_ghz) + 92.44
            atm_loss = 0.4 * (d_m / 1000)  # ~0.4 dB/km oxygen absorption
        else:  # eband
            freq_ghz = 73.0
            fs_pl = 20 * np.log10(d_m) + 20 * np.log10(freq_ghz) + 92.44
            atm_loss = 0.1 * (d_m / 1000)  # lower atmospheric loss
        return fs_pl + atm_loss

    def dynamic_bh_power(self, aggregate_traffic_bps,
                          distance_m, band='vband'):
        """
        Compute BH link dynamic power consumption p^BH_d (Eq. 8).
        Returns power in dBm.
        """
        G_rx = self.G_rx_vband if band == 'vband' else self.G_rx_eband
        PL   = self.path_loss_bh(distance_m, band)

        # Minimum SINR required (Eq. 9)
        spectral_eff = aggregate_traffic_bps / self.eta_bh
        if spectral_eff <= 0:
            SINR_min = -30.0
        else:
            SINR_min = 10 * np.log10(max(2 ** spectral_eff - 1, 1e-10))

        # p^BH_d = SINR_min - G_rx + L_rx + PL + LM + Tn + Nf  (Eq. 8)
        p_BH_d = (SINR_min
                  - G_rx
                  + self.L_rx
                  + PL
                  + self.L_M
                  + self.T_n
                  + self.N_f)
        return p_BH_d

    def max_bh_tx_power(self, band='vband'):
        """
        Maximum BH transmission power T^BH_max (Eq. 12-13).
        """
        x = 50 if band == 'vband' else 50   # dBi antenna gain
        EIRP_max = self.cfg['EIRP_max'] - 2 * x  # simplified Eq.13
        G_tx = 36 if band == 'vband' else 43
        L_tx = 5.0
        T_BH_max = EIRP_max + L_tx - G_tx
        return T_BH_max

    # ------------------------------------------------------------------
    # PRB Calculation
    # ------------------------------------------------------------------

    def compute_prb(self, demand_bps, sinr_db):
        """
        Required PRBs for UE u to connect BS i (Eq. 1).
        Γ_{i,u} = α_u / (η * log2(1 + SINR_{i,u}))
        """
        sinr_linear = 10 ** (sinr_db / 10)
        capacity_per_prb = self.eta_an * np.log2(1 + sinr_linear)
        if capacity_per_prb <= 0:
            return float('inf')
        return demand_bps / capacity_per_prb
