"""
actor.py  —  Policy network π(a|s; θ)
critic.py —  Value  network Q(s,a; φ)
binary_layer.py — STE binary layer for C1/C2
"""

# ======================================================================
# binary_layer.py
# ======================================================================
import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np


class StraightThroughBinary(torch.autograd.Function):
    """
    Straight-Through Estimator (STE) for binary activations.
    Forward : hard threshold at 0.5
    Backward: gradient passes through sigmoid (differentiable)
    Enforces C1 and C2 binary constraints.
    """
    @staticmethod
    def forward(ctx, x):
        return (x >= 0.5).float()

    @staticmethod
    def backward(ctx, grad_output):
        return grad_output   # straight-through


class BinaryLayer(nn.Module):
    def forward(self, x):
        prob = torch.sigmoid(x)
        return StraightThroughBinary.apply(prob)


# ======================================================================
# actor.py  —  Policy Network
# ======================================================================

class Actor(nn.Module):
    """
    Policy network maps state → action.
    Output is split into:
      - UE association  (sigmoid per UE-BS pair)
      - BH routing      (sigmoid per link)
      - Sleep decisions (sigmoid per s-BS / BH link)
    """

    def __init__(self, state_dim, action_dim, hidden_dim=256):
        super().__init__()

        # Shared feature extractor
        self.feature = nn.Sequential(
            nn.Linear(state_dim, hidden_dim),
            nn.ReLU(),
            nn.LayerNorm(hidden_dim),
            nn.Linear(hidden_dim, hidden_dim),
            nn.ReLU(),
            nn.LayerNorm(hidden_dim),
            nn.Linear(hidden_dim, 128),
            nn.ReLU(),
        )

        # Output head
        self.output = nn.Linear(128, action_dim)

    def forward(self, state):
        """Returns continuous action in [0, 1]."""
        feat = self.feature(state)
        return torch.sigmoid(self.output(feat))


# ======================================================================
# critic.py  —  Value Network
# ======================================================================

class Critic(nn.Module):
    """
    Q-value network Q(s, a; φ).
    Takes (state, action) → scalar Q-value.
    """

    def __init__(self, state_dim, action_dim, hidden_dim=256):
        super().__init__()

        # Q1 network
        self.q1 = nn.Sequential(
            nn.Linear(state_dim + action_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, 128),
            nn.ReLU(),
            nn.Linear(128, 1),
        )

        # Q2 network (Twin Critic for TD3 / SAC)
        self.q2 = nn.Sequential(
            nn.Linear(state_dim + action_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, 128),
            nn.ReLU(),
            nn.Linear(128, 1),
        )

    def forward(self, state, action):
        """Returns Q1 and Q2 values."""
        x = torch.cat([state, action], dim=-1)
        return self.q1(x), self.q2(x)

    def Q1(self, state, action):
        x = torch.cat([state, action], dim=-1)
        return self.q1(x)
